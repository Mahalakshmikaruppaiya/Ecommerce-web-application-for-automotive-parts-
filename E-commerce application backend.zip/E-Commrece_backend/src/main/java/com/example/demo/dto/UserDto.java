package com.example.demo.dto;

public class UserDto {
	private int id;
	
private String ename;
	
private String email;
private String password;
public UserDto() {
	super();
}
public UserDto(int id, String ename, String email, String password) {
	super();
	this.id = id;
	this.ename = ename;
	this.email = email;
	this.password = password;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
@Override
public String toString() {
	return "UserDto [id=" + id + ", ename=" + ename + ", email=" + email + ", password=" + password + "]";
}

}