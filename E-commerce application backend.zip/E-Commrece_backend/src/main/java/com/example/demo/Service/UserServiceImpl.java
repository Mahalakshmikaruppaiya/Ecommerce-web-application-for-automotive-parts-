package com.example.demo.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;


import com.example.demo.dto.LoginDTO;
import com.example.demo.dto.UserDto;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepo;
import com.example.demo.response.LoginResponse;



@Service
public class UserServiceImpl implements UserService {
@Autowired
private UserRepo userrepo;
@Autowired
private PasswordEncoder passwordEncoder;
	@Override
	public String addUser(UserDto userdto) {
		User user=new User(
				userdto.getId(),
				userdto.getEname(),
				userdto.getEmail(),
				this.passwordEncoder.encode(userdto.getPassword())
				
				);
		userrepo.save(user);
				
		return user.getName();
	}
	UserDto userdto;
	@Override
	public LoginResponse LoginUser(LoginDTO loginDTO) {
		String msg="";
		User user1=userrepo.findByEmail(loginDTO.getEmail());
		if(user1!=null)
		{
			String password=loginDTO.getPassword();
			String encodedPassword=user1.getPassword();
			Boolean isPwdRight=passwordEncoder.matches(password, encodedPassword);
			if(isPwdRight)
			{
Optional<User>employee=userrepo.findOneByEmailAndPassword(loginDTO.getEmail(),encodedPassword);
			if(employee.isPresent())
			{
				return new LoginResponse("Login Successfully",true);
			}
			else
			{
				return new LoginResponse("Login Failed",false);
			}
			}else
			{
				return new LoginResponse("Password Not Match",false);
			}
		}else
		{
			return new LoginResponse("Email not exist",false);
	}
	}
}
		

