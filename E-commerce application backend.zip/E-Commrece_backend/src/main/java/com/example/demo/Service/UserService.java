package com.example.demo.Service;


import com.example.demo.dto.LoginDTO;
import com.example.demo.dto.UserDto;
import com.example.demo.response.LoginResponse;


public interface UserService {
String addUser(UserDto userdto);
LoginResponse LoginUser(LoginDTO loginDTO);
}

