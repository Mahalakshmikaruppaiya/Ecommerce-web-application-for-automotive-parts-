package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Service.UserService;
import com.example.demo.dto.LoginDTO;
import com.example.demo.dto.UserDto;
import com.example.demo.response.LoginResponse;


@RestController
@CrossOrigin("*")
@RequestMapping("api/v1/")
public class UserController {
@Autowired
private UserService userService;
@PostMapping(path="/register")
public String saveEmployee(@RequestBody UserDto userdto)
{
	String id=userService.addUser(userdto);		
	return id;

}
@PostMapping(path="/login")
public ResponseEntity<?>LoginUser(@RequestBody LoginDTO loginDTO)
{
	 LoginResponse loginResponse=userService.LoginUser(loginDTO);
return ResponseEntity.ok(loginResponse);
}
}